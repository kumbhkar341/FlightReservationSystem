package com.frs.bean;

public class Route {
	
	private int RouteId ,Faree;
	private String Source,Destination,TravelDuration;

	public int getRouteId() {
		return RouteId;
	}
	public void setRouteId(int routeId) {
		RouteId = routeId;
	}
	public int getFaree() {
		return Faree;
	}
	public void setFaree(int faree) {
		Faree = faree;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		Source = source;
	}
	public String getDestination() {
		return Destination;
	}
	public void setDestination(String destination) {
		Destination = destination;
	}
	public String getTravelDuration() {
		return TravelDuration;
	}
	public void setTravelDuration(String travelDuration) {
		TravelDuration = travelDuration;
	}
	
}
